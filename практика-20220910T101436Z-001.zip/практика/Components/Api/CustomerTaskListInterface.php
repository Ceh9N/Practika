<?php

namespace ArseniyInk\Components\Api;

use ArseniyInk\Components\Api\Data\TaskInterface;

interface CustomerTaskListInterface
{
    /**
     * @return TaskInterface[]
     */
    public function getList();
}
