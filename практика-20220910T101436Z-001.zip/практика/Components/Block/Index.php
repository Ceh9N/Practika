<?php
declare(strict_types=1);

namespace ArseniyInk\Components\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Store\Model\StoreManagerInterface;

class Index extends Template
{

    private $storeManager;

    public function __construct(
        StoreManagerInterface  $storeManager,
        Context                $context,
        array                  $data = []
    ) {
        $this->storeManager = $storeManager;
        parent::__construct($context, $data);
    }


}




