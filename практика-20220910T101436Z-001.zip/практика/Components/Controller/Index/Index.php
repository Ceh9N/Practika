<?php
declare(strict_types=1);

namespace ArseniyInk\Components\Controller\Index;

use ArseniyInk\Components\Api\TaskManagementInterface;
use ArseniyInk\Components\Service\TaskRepository;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
//use ArseniyInk\Components\Model\Task;
use ArseniyInk\Components\Model\ResourceModel\Task as TaskResource;
use ArseniyInk\Components\Model\TaskFactory;

class Index extends Action
{

    /**
     * @var TaskResource
     */
    private $taskResource;

    /**
     * @var TaskFactory
     */
    private $taskFactory;

    /**
     * @var TaskRepository
     */
    private $taskRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;


    /**
     * @var TaskManagementInterface
     */
    private $taskManagement;

    public function __construct(
        Context $context,
        TaskFactory $taskFactory,
        TaskResource $taskResource,
        TaskRepository $taskRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        TaskManagementInterface $taskManagement
    ) {
        parent::__construct($context);
       $this->taskFactory = $taskFactory;
       $this->taskResource = $taskResource;
       $this->taskRepository = $taskRepository;
       $this->searchCriteriaBuilder = $searchCriteriaBuilder;
       $this->taskManagement = $taskManagement;
    }

    public function execute()
    {
//        $task = $this->taskRepository->get(1);
//        $task->setData('status', 'complete');
//
//        $this->taskManagement->save($task);
//
//        var_dump($this->taskRepository->getList($this->searchCriteriaBuilder->create())->getItems());
//        return ;
//        $task = $this->taskFactory->create();
//
//        $task->setData([
//            'label' => 'New Task 22',
//            'status' => 'open',
//            'customer_id' => 1
//        ]);
//        var_dump($task->getData());
//        $this->taskResource->save($task);

        return $this->resultFactory->create(ResultFactory::TYPE_PAGE);
    }
}
