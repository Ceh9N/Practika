<?php

declare(strict_types=1);

namespace ArseniyInk\Components\Service;

use ArseniyInk\Components\Api\Data\TaskInterface;
use ArseniyInk\Components\Api\TaskManagementInterface;
use ArseniyInk\Components\Model\ResourceModel\Task;

class TaskManagement implements TaskManagementInterface
{
    private $resource;

    public function __construct(
       Task $resource
    ) {
       $this->resource = $resource;
    }

    public function save(TaskInterface $task)
    {
        $this->resource->save($task);
    }
    
    public function delete(TaskInterface $task)
    {
        $this->resource->delete($task);
    }
}
